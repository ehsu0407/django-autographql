ALLOWED_ACTIONS = ['retrieve', 'list', 'create', 'update', 'delete']
