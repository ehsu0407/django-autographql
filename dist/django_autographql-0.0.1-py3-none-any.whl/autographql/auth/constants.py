PERMISSION_DENIED_MESSAGE = 'You do not have permission to perform this action'
